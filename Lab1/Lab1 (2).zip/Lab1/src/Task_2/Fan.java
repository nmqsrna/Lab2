/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_2;

/**
 *
 * @author : Nur Mas Qasrina 
 * Date : 13 oct 2025
 */
public class Fan {
    
    //question a
    public static final int PERLAHAN = 1;
    public static final int SEDERHANA = 2;
    public static final int LAJU = 3;
    
    //question b,c,d,e
    private int speed;
    private boolean on;
    private double radius; 
    private String color;
    
    //question g
    public Fan(){
        
        speed = PERLAHAN;
        on = false;
        radius = 5;
        color = "biru";
    }
    
    //question f
    public void setSpeed(int speed){
        this.speed = speed;
    }
    
    public int getSpeed(){
        return speed;
    }
    
    public void setOn(boolean on){
        this.on = on;
    }
    
    public boolean isOn(){
        return on;
    }
    
    public void setRadius(double radius){
        this.radius = radius;
    }
    
    public double getRadius(){
        return radius;
    }
    
    public void setColor(String color){
        this.color = color;
    }
    
    public String getColor(){
        return color;
    }
    
    //question h
    public String toString(){
        if(on){
            return "Fan is on | Speed : " +speed +" | Color : " +color +" | Radius : " +radius;
        }
        else{
            return "Fan is off " + " | Color : " +color +" | Radius : " +radius;
        }
    }
}

