/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_2;

/**
 *
 * @author : Nur Mas Qasrina 
 * Date : 13 oct 2025
 */
public class TestFan {
    public static void main(String[] args){
        
        //first Fan object
        Fan fan1 = new Fan();
        fan1.setSpeed(Fan.LAJU);
        fan1.setRadius(10);
        fan1.setColor("merah");
        fan1.setOn(true);
        
        //sec Fan object
        Fan fan2 = new Fan();
        fan2.setSpeed(Fan.SEDERHANA);
        fan2.setRadius(5);
        fan2.setColor("biru");
        fan2.setOn(false);
        
        //display
        System.out.println(fan1.toString());
        System.out.println(fan2.toString());
    }
}
