/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Task_1;

/**
 *
 * @author : Nur Mas Qasrina 
 * Date : 13 oct 2025
 */

public class RectangleTest {
    
    public static void main(String[] args){
        
        Rectangle myRect = new Rectangle(12.5, 10);
        
        //myRect.setWidth(2.0);
        //myRect.setHeight(3.3);
        double theAreamy = myRect.area();
        double thePerimeter = myRect.perimeter();
        
        
        System.out.println("My rectangle has area " +theAreamy);
        System.out.println("Width is " +myRect.getWidth());
        System.out.println("Height is " +myRect.getHeight());
        System.out.println("My rectangle has perimeter " +thePerimeter);
    }
}
