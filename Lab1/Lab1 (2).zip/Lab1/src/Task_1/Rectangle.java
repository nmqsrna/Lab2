/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Task_1;

/**
 *
 * @author : Nur Mas Qasrina 
 * Date : 13 oct 2025
 */
public class Rectangle {
    

    //instance variable
    private double height ;
    private double width ;
    
    //constructor
    public Rectangle(double w, double h){
        width = w;
        height = h;
    }
    
    public double area(){
        
        double theArea;
        theArea = height * width;
        return theArea;
        
    }
    
    //getter method
    public double getWidth(){
        return width;
    }
    
    public double getHeight(){
        return height;
    }
    
    //setter method
    public void setWidth(double w){
        width = w;
    }
    
    public void setHeight(double h){
        height = h;
    }
    
    //perimeter
    public double perimeter(){
        double thePerimeter = 2 *(width + height);
        return thePerimeter;
        
    }
}
